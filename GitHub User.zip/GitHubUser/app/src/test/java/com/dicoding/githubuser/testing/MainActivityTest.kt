package com.dicoding.githubuser.testing

class MainActivityTest {

    @org.junit.jupiter.api.Test
    fun onCreate() {
    }

    @org.junit.jupiter.api.Test
    fun showUser() {
    }
}